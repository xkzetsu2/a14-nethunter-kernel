// SPDX-License-Identifier: GPL-2.0

#ifndef __ARM64_KVM_PKVM_H__
#define __ARM64_KVM_PKVM_H__

#include <linux/arm_ffa.h>
#include <linux/memblock.h>
#include <linux/scatterlist.h>
#include <asm/kvm_pgtable.h>
#include <asm/sysreg.h>


#define KVM_MAX_PVMS 255

#define HYP_MEMBLOCK_REGIONS 128
#define PVMFW_INVALID_LOAD_ADDR	(-1)

int kvm_arm_vm_ioctl_pkvm(struct kvm *kvm, struct kvm_enable_cap *cap);
int kvm_init_pvm(struct kvm *kvm, unsigned long type);
int create_el2_shadow(struct kvm *kvm);
void kvm_shadow_destroy(struct kvm *kvm);




#define PVM_ID_AA64PFR0_ALLOW (\
	ARM64_FEATURE_MASK(ID_AA64PFR0_FP) | \
	ARM64_FEATURE_MASK(ID_AA64PFR0_ASIMD) | \
	ARM64_FEATURE_MASK(ID_AA64PFR0_DIT) \
	)


#define PVM_ID_AA64PFR0_RESTRICT_UNSIGNED (\
	FIELD_PREP(ARM64_FEATURE_MASK(ID_AA64PFR0_EL0), ID_AA64PFR0_ELx_64BIT_ONLY) | \
	FIELD_PREP(ARM64_FEATURE_MASK(ID_AA64PFR0_EL1), ID_AA64PFR0_ELx_64BIT_ONLY) | \
	FIELD_PREP(ARM64_FEATURE_MASK(ID_AA64PFR0_EL2), ID_AA64PFR0_ELx_64BIT_ONLY) | \
	FIELD_PREP(ARM64_FEATURE_MASK(ID_AA64PFR0_EL3), ID_AA64PFR0_ELx_64BIT_ONLY) | \
	FIELD_PREP(ARM64_FEATURE_MASK(ID_AA64PFR0_RAS), ID_AA64PFR0_RAS_V1) \
	)


#define PVM_ID_AA64PFR1_ALLOW (\
	ARM64_FEATURE_MASK(ID_AA64PFR1_BT) | \
	ARM64_FEATURE_MASK(ID_AA64PFR1_SSBS) \
	)


#define PVM_ID_AA64MMFR0_ALLOW (\
	ARM64_FEATURE_MASK(ID_AA64MMFR0_BIGENDEL) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR0_SNSMEM) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR0_BIGENDEL0) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR0_EXS) \
	)


#define PVM_ID_AA64MMFR0_RESTRICT_UNSIGNED (\
	FIELD_PREP(ARM64_FEATURE_MASK(ID_AA64MMFR0_PARANGE), ID_AA64MMFR0_PARANGE_40) | \
	FIELD_PREP(ARM64_FEATURE_MASK(ID_AA64MMFR0_ASID), ID_AA64MMFR0_ASID_16) \
	)


#define PVM_ID_AA64MMFR1_ALLOW (\
	ARM64_FEATURE_MASK(ID_AA64MMFR1_HADBS) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR1_VMIDBITS) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR1_HPD) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR1_PAN) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR1_SPECSEI) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR1_ETS) \
	)


#define PVM_ID_AA64MMFR2_ALLOW (\
	ARM64_FEATURE_MASK(ID_AA64MMFR2_CNP) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR2_UAO) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR2_IESB) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR2_AT) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR2_IDS) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR2_TTL) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR2_BBM) | \
	ARM64_FEATURE_MASK(ID_AA64MMFR2_E0PD) \
	)


#define PVM_ID_AA64ZFR0_ALLOW (0ULL)


#define PVM_ID_AA64DFR0_ALLOW (0ULL)
#define PVM_ID_AA64DFR1_ALLOW (0ULL)


#define PVM_ID_AA64AFR0_ALLOW (0ULL)
#define PVM_ID_AA64AFR1_ALLOW (0ULL)


#define PVM_ID_AA64ISAR0_ALLOW (\
	ARM64_FEATURE_MASK(ID_AA64ISAR0_AES) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_SHA1) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_SHA2) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_CRC32) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_ATOMICS) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_RDM) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_SHA3) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_SM3) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_SM4) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_DP) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_FHM) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_TS) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_TLB) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR0_RNDR) \
	)

#define PVM_ID_AA64ISAR1_ALLOW (\
	ARM64_FEATURE_MASK(ID_AA64ISAR1_DPB) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_APA) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_API) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_JSCVT) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_FCMA) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_LRCPC) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_GPA) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_GPI) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_FRINTTS) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_SB) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_SPECRES) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_BF16) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_DGH) | \
	ARM64_FEATURE_MASK(ID_AA64ISAR1_I8MM) \
	)


static inline int pkvm_get_max_brps(void)
{
	int num = FIELD_GET(ARM64_FEATURE_MASK(ID_AA64DFR0_BRPS),
			    PVM_ID_AA64DFR0_ALLOW);

	
	return num ? num + 1 : 0;
}


static inline int pkvm_get_max_wrps(void)
{
	int num = FIELD_GET(ARM64_FEATURE_MASK(ID_AA64DFR0_WRPS),
			    PVM_ID_AA64DFR0_ALLOW);

	return num ? num + 1 : 0;
}

extern struct memblock_region kvm_nvhe_sym(hyp_memory)[];
extern unsigned int kvm_nvhe_sym(hyp_memblock_nr);

extern phys_addr_t kvm_nvhe_sym(pvmfw_base);
extern phys_addr_t kvm_nvhe_sym(pvmfw_size);

static inline unsigned long
hyp_vmemmap_memblock_size(struct memblock_region *reg, size_t vmemmap_entry_size)
{
	unsigned long nr_pages = reg->size >> PAGE_SHIFT;
	unsigned long start, end;

	start = (reg->base >> PAGE_SHIFT) * vmemmap_entry_size;
	end = start + nr_pages * vmemmap_entry_size;
	start = ALIGN_DOWN(start, PAGE_SIZE);
	end = ALIGN(end, PAGE_SIZE);

	return end - start;
}

static inline unsigned long hyp_vmemmap_pages(size_t vmemmap_entry_size)
{
	unsigned long res = 0, i;

	for (i = 0; i < kvm_nvhe_sym(hyp_memblock_nr); i++) {
		res += hyp_vmemmap_memblock_size(&kvm_nvhe_sym(hyp_memory)[i],
						 vmemmap_entry_size);
	}

	return res >> PAGE_SHIFT;
}

static inline unsigned long hyp_shadow_table_pages(size_t shadow_entry_size)
{
	return PAGE_ALIGN(KVM_MAX_PVMS * shadow_entry_size) >> PAGE_SHIFT;
}

static inline unsigned long __hyp_pgtable_max_pages(unsigned long nr_pages)
{
	unsigned long total = 0, i;

	
	for (i = 0; i < KVM_PGTABLE_MAX_LEVELS; i++) {
		nr_pages = DIV_ROUND_UP(nr_pages, PTRS_PER_PTE);
		total += nr_pages;
	}

	return total;
}

static inline unsigned long __hyp_pgtable_total_pages(void)
{
	unsigned long res = 0, i;

	
	for (i = 0; i < kvm_nvhe_sym(hyp_memblock_nr); i++) {
		struct memblock_region *reg = &kvm_nvhe_sym(hyp_memory)[i];
		res += __hyp_pgtable_max_pages(reg->size >> PAGE_SHIFT);
	}

	return res;
}

static inline unsigned long hyp_s1_pgtable_pages(void)
{
	unsigned long res;

	res = __hyp_pgtable_total_pages();

	
	res += __hyp_pgtable_max_pages(SZ_1G >> PAGE_SHIFT);

	return res;
}

static inline unsigned long host_s2_pgtable_pages(void)
{
	unsigned long res;

	
	res = __hyp_pgtable_total_pages() + 16;

	
	res += __hyp_pgtable_max_pages(SZ_1G >> PAGE_SHIFT);

	return res;
}

#define KVM_FFA_MBOX_NR_PAGES	1


#define KVM_FFA_MAX_NR_CONSTITUENTS	4096

static inline unsigned long hyp_ffa_proxy_pages(void)
{
	size_t desc_max;

	
	BUILD_BUG_ON(KVM_FFA_MAX_NR_CONSTITUENTS < SG_MAX_SEGMENTS);

	
	desc_max = sizeof(struct ffa_mem_region) +
		   sizeof(struct ffa_mem_region_attributes) +
		   sizeof(struct ffa_composite_mem_region) +
		   KVM_FFA_MAX_NR_CONSTITUENTS * sizeof(struct ffa_mem_region_addr_range);

	
	return (2 * KVM_FFA_MBOX_NR_PAGES) + DIV_ROUND_UP(desc_max, PAGE_SIZE);
}

#endif	
